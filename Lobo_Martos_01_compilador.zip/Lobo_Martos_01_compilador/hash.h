#ifndef HASH_H
#define	HASH_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_LONG_ID 100
#define VARIABLE 1
#define PARAMETRO 2
#define FUNCION 3

typedef enum { ERROR = -1, OK = 0 } STATUS;

typedef struct {
    char lexema[MAX_LONG_ID];
    int categoria;
    int clase;
    int tipo;
    int tamanio;
    int n_vbl_locales;
    int pos_vbl_locales;
    int n_parametro;
    int pos_parametro;
} HASH;

typedef struct nodo {
	HASH elemento;
	struct nodo * next;
} NODO;

typedef NODO * TABLA;

TABLA * iniTablaHash();
NODO * crearNodo(char * lexema, int categoria, int tipo, int clase, int tamanio, int n_vbl_locales, int pos_vbl_locales, int n_parametro, int pos_parametro);
HASH * buscarLexema(TABLA * tabla, char * lexema);
int insertarEnLaTabla(TABLA * tabla, char * lexema, int categoria, int tipo, int clase, int tamanio, int n_vbl_locales, int pos_vbl_locales, int n_parametro, int pos_parametro);
int posicionTabla(char * lexema);
void imprimirNodoTabla(HASH * tabla);
void liberarTabla(TABLA *tabla);
void liberarNodo(NODO* nodo);
int get_Categoria(HASH * nodo);
int get_Tipo(HASH * nodo); 
int get_Clase(HASH * nodo);
int get_Tamanio(HASH * nodo);
int get_n_Parametro(HASH * nodo);
int get_pos_Parametro(HASH * nodo);
int get_n_vbl_locales(HASH * nodo);
int get_pos_vbl_locales(HASH * nodo);
void modificar_n_Parametro(HASH * nodo, int n_parametro);
void modificar_n_vbl_locales(HASH * nodo, int n_vbl_locales);



#endif	/* HASH_H */

