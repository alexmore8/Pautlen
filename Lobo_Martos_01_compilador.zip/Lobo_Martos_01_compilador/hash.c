#include "hash.h"

TABLA *iniTablaHash(){
	TABLA *tabla;
	int i;
	
	tabla = (TABLA *) malloc (100 * sizeof(TABLA));
	if (tabla == NULL){
		return NULL;
	}
	for(i = 0; i < 100; i++) {
		tabla[i] = NULL;
	}
	return tabla;
}

NODO * crearNodo(char * lexema, int categoria, int tipo, int clase, int tamanio, int n_vbl_locales, int pos_vbl_locales, int n_parametro, int pos_parametro){
	NODO * nodo;
	nodo = (NODO*) malloc(sizeof (NODO));
	
    strcpy(nodo->elemento.lexema, lexema);
    nodo->elemento.categoria = categoria;
    nodo->elemento.clase = clase;
    nodo->elemento.tipo = tipo;
    nodo->elemento.tamanio = tamanio;
    nodo->elemento.n_vbl_locales = n_vbl_locales;
    nodo->elemento.pos_vbl_locales = pos_vbl_locales;
    nodo->elemento.n_parametro = n_parametro;
    nodo->elemento.pos_parametro = pos_parametro;

    nodo->next = NULL;
    return nodo;
}

HASH * buscarLexema(TABLA * tabla, char * lexema){
	int i;
    TABLA aux;
    if (tabla == NULL){
        return NULL;
	}
    i = posicionTabla(lexema);
    if (i == -1){
        return NULL;
	}
    for (aux = tabla[i]; aux != NULL; aux = aux->next){
        if (strcmp(aux->elemento.lexema, lexema) == 0){
            return &(aux->elemento);
		}
	}
    return NULL;
}

int insertarEnLaTabla(TABLA * tabla, char * lexema, int categoria, int tipo, int clase, int tamanio, int n_vbl_locales, int pos_vbl_locales, int n_parametro, int pos_parametro){
	NODO * nodo;
	int i;
    if (tabla == NULL){
        return ERROR;
	}
    nodo = crearNodo(lexema, categoria, tipo, clase, tamanio, n_vbl_locales, pos_vbl_locales, n_parametro, pos_parametro);
    if (nodo == NULL){
        return ERROR;
	}
	i = posicionTabla(lexema);
    nodo->next = tabla[i];
    tabla[i] = nodo;
    return OK;
}

int posicionTabla(char *lexema){
    int cont = 0, i;
    if(lexema == NULL){
        return -1;
	}
    for(i = 0; i < strlen(lexema); i++){
        cont += lexema[i];
	}
    return cont % 100;
}

void imprimirNodoTabla(HASH * tabla){	
	if(tabla == NULL){
        return;
    }
	printf("%s\n", tabla->lexema);
    printf("%d\n", tabla->categoria);
    printf("%d\n", tabla->tipo);
	printf("%d\n", tabla->clase);
    printf("%d\n", tabla->tamanio);
    printf("%d\n", tabla->n_parametro);
    printf("%d\n", tabla->pos_parametro);
    printf("%d\n", tabla->n_vbl_locales);
    printf("%d\n", tabla->pos_vbl_locales);
}

void liberarTabla(TABLA * tabla){
    NODO * aux = NULL;
    int i;
    if(tabla == NULL) {
        return;
    }
    for(i = 0; i < 100; i++) {
        if(tabla[i]!=NULL){
            while(tabla[i]->next != NULL) {
                aux = tabla[i];
                tabla[i] = tabla[i]->next;
                liberarNodo(aux);
                }
        }
        free(tabla[i]);
    }
    free(tabla);
    return;
}

void liberarNodo(NODO* nodo){	
    free(nodo);
}

int get_Categoria(HASH * nodo){	
    return nodo->categoria;
}

int get_Tipo(HASH * nodo){	
    return nodo->tipo;
} 

int get_Clase(HASH * nodo){
	
    return nodo->clase;
}

int get_Tamanio(HASH * nodo){
    return nodo->tamanio;
}

int get_n_Parametro(HASH * nodo){	
    return nodo->n_parametro;
}

int get_pos_Parametro(HASH * nodo){	
    return nodo->pos_parametro;
}

int get_n_vbl_locales(HASH * nodo){	
    return nodo->n_vbl_locales;
}

int get_pos_vbl_locales(HASH * nodo){	
    return nodo->pos_vbl_locales;
}

void modificar_n_Parametro(HASH * nodo, int n_parametro){	
    nodo->n_parametro = n_parametro;
}
void modificar_n_vbl_locales(HASH * nodo, int n_vbl_locales){	
    nodo->n_vbl_locales = n_vbl_locales;
}
































